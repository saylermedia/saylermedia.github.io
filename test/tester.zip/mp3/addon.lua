
local ffmpeg

if ffi.abi('win') then
	ffmpeg = ffi.load('D:\\tools\\ffmpeg\\0\\bin\\avformat-57.dll')
else
	ffmpeg = ffi.load('avformat_iconbit')
end

ffi.cdef [[
	typedef struct AVFormatContext {
    const void *av_class;
    void *iformat;
    void *oformat;
    void *priv_data;
    void *pb;
    int ctx_flags;
    unsigned int nb_streams;
    void **streams;
    char filename[1024];
    char *url;
    int64_t start_time;
    int64_t duration;
	} AVFormatContext;
	
	int avformat_open_input(AVFormatContext **ps, const char *url, void *fmt, void **options);
	void avformat_close_input(AVFormatContext **s);
	int avformat_find_stream_info(AVFormatContext *ic, void **options);
]]

local cached = {}

function onCreate(args)
	--local t = {view = 'simple', type = 'folder'}
	
	local ispls
	
	local t = url_dump(args['url'] or 'https://dl.dropbox.com/s/hb6khev7l0j6ohv/Vinil_Flac.m3u')
	for _, v in ipairs(t) do
		local url = v['url']
		if string.find(url, '%.m3u$') then
			v['url'] = url_for{url = url}
			ispls = true
		else
			v['icon'] = get_image('audio.png')
			v['meta'] = meta_for('get_duration', {url = url})
			v['type'] = 'audio'
		end
	end
	
	if ispls then
		t['view'] = 'grid'
	else
		t['view'] = 'simple'
	end
	
	t['type'] = 'folder'
	
	return t
end

local function get(url)
	local ctx = ffi.new('AVFormatContext*[1]')
	assert(ffmpeg.avformat_open_input(ctx, url, nil, nil) == 0, 'Open failed!')
	
	ffi.gc(ctx, ffmpeg.avformat_close_input)
	assert(ffmpeg.avformat_find_stream_info(ctx[0], nil) >= 0, 'avformat_find_stream_info() failed!')

	return ctx[0].duration / 1000000
end

function get_duration(args)
	local url = args['url']
	return {duration = cached[url] or get(url)}
end
