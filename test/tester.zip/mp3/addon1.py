import ssl 

try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    pass
else:
    ssl._create_default_https_context = _create_unverified_https_context

import urllib.request
import re
from imc import get_tag, url_for, get_image, meta_for
import ffmpeg

def unload():
	pass

def main(args):
	t = {'view' : 'simple', 'type' : 'folder'}
	t['items'] = items = []
	req = urllib.request.urlopen(get_tag('url'))
	for res in re.finditer('"name":"(.*)","url":"(.*)"', req.read().decode('UTF-8')):
		meta = meta_for('get_duration', {'url' : res[2]})
		items.append({'title' :res[1], 'url' : res[2], 'type' : 'audio', 'icon' : 'http://files.iconbit.com/IMC/menu/audio.png', 'meta' : meta})
	return t

def get_duration(args):
	if args['type'] == 'EPG':
		pass
	else:
		try:
			media = ffmpeg.Media(args['url'])
			duration = int(media.get_duration()/1000000)
			del media
			return {'duration' : duration}
		except:
			pass
