-- Python testing

function onLoad()
	print('Hello from python!')
	return 1
end

function onUnLoad()
	print('Buy from python!')
end

local function execute(n, args)
	return string.format('%s\t%s\t%s', python.execute(n, args))
end

local function str(s, args)
	return string.format('%s\t%s\t%s', python.string(s, args))
end

function onCreate(args)
	if not args.q then
		local t = {view = 'simple', menu = {}}
		table.insert(t['menu'], {title = 'custom', url = '#stream/q=cust'})
		table.insert(t, {title = 'ivi', url = '#self/q=ivi'})
		table.insert(t, {title = 'num', url = '#stream/q=num'})
		table.insert(t, {title = 'requests', url = '#stream/q=requests'})
		table.insert(t, {title = 'python._VERSION', url = '#stream/q=ver'})
		table.insert(t, {title = 'python._PATH', url = '#stream/q=path'})
		table.insert(t, {title = 'python.string(\'import sys;print("Hello World!")\')', url = '#stream/q=s1'})
		table.insert(t, {title = 'python.string(\'print(123 ** 123)\')', url = '#stream/q=s2'})
		table.insert(t, {title = 'python.execute(\'/sdcard/youtube-dl\')', url = '#stream/q=f1'})
		table.insert(t, {title = 'python.execute(\'/sdcard/youtube-dl\', {\'--help\'})', url = '#stream/q=f2'})
		table.insert(t, {title = 'python.execute(\'/sdcard/dl\')', url = '#stream/q=f3'})
		table.insert(t, {title = 'python.execute(\'/sdcard/dl\', {\'--help\'})', url = '#stream/q=f4'})
		table.insert(t, {title = 'python.execute(\'/sdcard/testpy\')', url = '#stream/q=f5'})
		table.insert(t, {title = 'python.import(\'youtube_dl\', \'/sdcard/youtube-dl\')', url = '#stream/q=import'})
		table.insert(t, {title = 'Run', url = '#stream/q=run'})
		table.insert(t, {title = 'Run --help', url = '#stream/q=run2'})
		table.insert(t, {title = 'Run --list-extractors', url = '#stream/q=run3'})
		table.insert(t, {title = 'python.imported(\'youtube_dl\')', url = '#stream/q=imported'})
		table.insert(t, {title = 'python.string(\'print(sys.dont_write_bytecode)\')', url = '#stream/q=dont'})
		table.insert(t, {title = 'python.finalize()', url = '#stream/q=finalize'})
		table.insert(t, {title = 'filmix', url = '#stream/q=filmix'})
		table.insert(t, {title = 'ciphers', url = '#stream/q=ciphers'})
		table.insert(t, {title = 'interp', url = '#stream/q=interp'})
		return t
	elseif args.q == 'num' then
		local r, x, e = python.string('import imc; print(imc.numargs())')
		if r then
			return {view = 'msgbox', message = x}
		else
			return {view = 'error', message = e}
		end
	elseif args.q == 'ivi' then
		require'tesssst'
		return {{url = '#stream/q=play&url=https://www.ivi.ru/watch/123559&t=ivi&package=asset://play.IMC.zip'}}
	elseif args.q == 'requests' then
		local r, x, e = python.string('import requests; print(requests.get("https://httpbin.org/get?one=123&two=321"))')
		if r then
			return {view = 'msgbox', message = x}
		else
			return {view = 'error', message = e}
		end
	elseif args.q == 'ver' then
		return {view = 'msgbox', message = python._VERSION}
	elseif args.q == 'path' then
		return {view = 'msgbox', message = python._PATH}
	elseif args.q == 's1' then
		return {view = 'msgbox', message = str('import sys;print("Hello World!")')}
	elseif args.q == 's2' then
		return {view = 'msgbox', message = str('print(123 ** 123)')}
	elseif args.q == 'f1' then
		return {view = 'msgbox', message = execute('/sdcard/youtube-dl')}
	elseif args.q == 'f2' then
		return {view = 'msgbox', message = execute('/sdcard/youtube-dl', {'--help'})}
	elseif args.q == 'f3' then
		return {view = 'msgbox', message = execute('/sdcard/dl')}
	elseif args.q == 'f4' then
		return {view = 'msgbox', message = execute('/sdcard/dl', {'--help'})}
	elseif args.q == 'f5' then
		return {view = 'msgbox', message = execute('/sdcard/testpy')}
	elseif args.q == 'import' then
		local res = python.import('youtube_dl', '/sdcard/youtube-dl')
		return {view = 'msgbox', message = tostring(res)}
	elseif args.q == 'importasync' then
		local res = python.import('youtube_dl', '/sdcard/youtube-dl', true)
		return {view = 'msgbox', message = tostring(res)}
	elseif args.q == 'run' then
		return {view = 'msgbox', message = str('youtube_dl.main()')}
	elseif args.q == 'run2' then
		return {view = 'msgbox', message = str('youtube_dl.main()', {'--help'})}
	elseif args.q == 'run3' then
		return {view = 'msgbox', message = str('youtube_dl.main()', {'--list-extractors'})}
	elseif args.q == 'imported' then
		return {view = 'msgbox', message = tostring(python.imported('youtube_dl'))}
	elseif args.q == 'dont' then
		return {view = 'msgbox', message = str('print(sys.dont_write_bytecode)')}
	elseif args.q == 'finalize' then
		python.finalize()
		return {view = 'refresh'}
	elseif args.q == 'filmix' then
		return {view = 'msgbox', message = str('import urllib.request\nprint(urllib.request.urlopen(\'https://filmix.online\').read())')}
	elseif args.q == 'ciphers' then
		local x = crypto.list('ciphers')
		local s = ''
		for _, v in ipairs(x) do
		  s = s .. ' ' .. v
		end
		return {view = 'msgbox', message = s}
	elseif args.q == 'cust' then
		if not args.keyword then
			return {view = 'keyword'}
		end
		return {view = 'msgbox', message = str(args.keyword)}
	elseif args.q == 'interp' then
		local i = python.interp()
		--local res = i:import('youtube_dl', '/sdcard/youtube-dl')
		local res = string.format('%s\t%s\t%s', i:string('print(123 ** 123123)', args))
		return {view = 'msgbox', message = tostring(res)}
	end
end
