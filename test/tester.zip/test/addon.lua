-- test plugin

print(_PACKAGE)

function onLoad()
	print('Hello from test!')
	return 1
end

function onUnLoad()
	print('Buy from test!')
end

local counter

-- #self/__func__=message
function message(args)
	counter = 0
	return {view = 'message', message = json.encode(args),next=url_for('message_next')}
end

function message_next(args)
	counter = counter + 1
	print('Counter = ' .. tostring(counter))
	if counter > 10 then
		return {view = 'message', message = 'Success'}
	end
	return {view = 'pass'}
end

-- #self/__func__=launch
function launch(args)
	android.execute{
		action = 'android.intent.action.VIEW',
		data = 'file:///sdcard/buck.mp4',
		type = 'video/mp4'
	}
	
	return {view = 'pass'}
end

-- #self/__func__=launch2
function launch2(args)
	android.execute({
		package = 'com.iconbit.sayler.mediacenter/com.iconbit.sayler.mediacenter.TestService'
	}, true)
	
	return {view = 'pass'}
end

-- #self/__func__=query
function query(args)
	local x = android.query{
		action = 'android.intent.action.VIEW',
		data = 'file:///sdcard/buck.mp4',
		type = 'video/mp4'
	}
	
	for _, v in ipairs(x) do
		v['annotation'] = v['url']
	end
	print(json.encode(x))
	
	return x
end

-- #self/__func__=startActivity
function startActivity(args)
	local r = android.startActivity{
		action = 'android.intent.action.VIEW',
		category = 'android.intent.category.DEFAULT',
		package = 'com.iconbit.sayler.mediacenter/com.iconbit.sayler.mediacenter.MainActivity',
		data = 'file::/dsfiel.mp4'
	}
	if r then
		return {view = 'message', message = 'OK'}
	end
	return {view = 'message', message = 'Error'}
end

-- #self/__func__=startService
function startService(args)
	local r = android.startService{
		package = 'com.iconbit.sayler.mediacenter/com.iconbit.sayler.mediacenter.TestService'
	}
	if r then
		return {view = 'message', message = 'OK'}
	end
	return {view = 'message', message = 'Error'}
end

-- #self/__func__=testffi
function testffi(args)
	ffi.cdef [[
		union foo {
			struct { uint8_t a; uint8_t b; };
			uint16_t v;
		};
	]]
	local x = ffi.new("union foo")
	x.a = 0xAA
	x.b = 0xFF
	return {view = 'message', message = x.a}
end

-- #self/__func__=message
function onCreate(args)	
	if not args.q then
		local t={view='simple'}
		table.insert(t,{title='Сообщение',url= url_for('message')})
		table.insert(t,{title='Пуск',url= url_for('launch')})
		table.insert(t,{title='Пуск service',url= url_for('launch2')})
		table.insert(t,{title='Пуск query',url= url_for('query')})
		table.insert(t,{title='Пуск startActivity',url= url_for('startActivity')})
		table.insert(t,{title='Пуск startService',url= url_for('startService')})
		table.insert(t,{title='Пуск testffi',url= url_for('testffi')})
		table.insert(t,{title='Ошибка',mrl='#stream/q=error', image = get_image('play.png')})
		table.insert(t,{title='Ввод строки',mrl='#stream/q=keyword', image = '#self/pause.png'})
		table.insert(t,{title='Выбор',mrl='#stream/q=select'})
		table.insert(t,{title='Авторизация',mrl='#stream/q=login'})
		table.insert(t,{title='Редирект',mrl='#stream/q=redir'})
		table.insert(t,{title='Назад',mrl='#stream/q=back'})
		table.insert(t,{title='О системе',mrl='#stream/q=about', image = '#self/icon_off.png'})
		table.insert(t,{title='Приложения',mrl='#stream/q=packages', image = '#self/next.png'})
		table.insert(t,{title='Установить',mrl='#stream/q=install'})
		table.insert(t,{title='Удалить',mrl='#stream/q=uninstall'})
		table.insert(t,{title='Музыка',mrl='#stream/q=music'})
		table.insert(t,{title='Зацикливание',mrl='#stream/q=loop'})
		--table.insert(t,{title='База данных',mrl='#stream/q=db'})
		table.insert(t,{title='Аккаунты',mrl='#stream/q=accounts'})
		table.insert(t,{title='Аккаунт',mrl='#stream/q=account'})
		table.insert(t,{title='Аккаунт выбр',mrl='#stream/q=account1'})
		local slaves = {
			{type = 'subtitle', url = 'http://server.com/video.srt'},
			{type = 'subtitle', url = 'http://server.com/video.smt'},
			{type = 'audio', url = 'http://server.com/video.mp3'},
		}
		table.insert(t,{title='Видео',mrl='http://server.com/video.mp4',slaves = slaves})
		return t
	elseif args.q == 'message' then
		return {view='message',message='Здесь находится сообщение пользователю...',next=url_for{'message_next'}}
	elseif args.q == 'error' then
		return {view='error',message='Здесь находится информация об ошибке...'}
	elseif args.q == 'keyword' then
		return {view='keyword',message='Введите ключевое слово:',keyword=args.keyword}
	elseif args.q == 'select' then
		local t={view='select',message='Выберите пункт'}
		table.insert(t,{title='Сообщение',mrl='#stream/q=message',image='#self/network.png'})
		table.insert(t,{title='Ошибка',mrl='#stream/q=error',image='#self/search.png'})
		table.insert(t,{title='Ввод строки',mrl='#stream/q=keyword',image='#self/hdd.png'})
		return t
	elseif args.q == 'login' then
		return {view='login',message='Введите ваши учетные данные',username=args.username,password=args.password,error='Здесь находится информация об ошибке...'}
	elseif args.q == 'redir' then
		return {{title='Новый редирект',mrl='#stream/'}}
	elseif args.q == 'back' then
		return {view = 'back'}
	elseif args.q == 'about' then
		local message = os.PLATFORM or 'Неизвестно'
		if message == 'ANDROID' then
			message = message .. ', SDK = ' .. os.ANDROID_SDK_INT
			if os.ANDROID_SIGNATURE_HASHCODE then
				message = message .. ', hashCode = ' .. os.ANDROID_SIGNATURE_HASHCODE
			end
			message = message .. ', brand = ' .. E'brand'
		end
		return {view = 'message', message = 'Система: ' .. message}
	elseif args.q == 'packages' then
		if args.name then
			return {view = 'message', message = 'Вы выбрали ' .. args.name}
		end
		local t={view='simple'}
		for name in string.gmatch(os.packages(), '([^,]+)') do
			table.insert(t,{title=name,mrl='#stream/q=packages&name=' .. name})
		end
		return t
	elseif args.q == 'install' then
		os.install('/sdcard/test.apk')
		local t={view='simple'}
		for name in string.gmatch(os.packages(), '([^,]+)') do
			table.insert(t,{title=name,mrl='#stream/q=packages&name=' .. name})
		end
		return t
	elseif args.q == 'uninstall' then
		os.uninstall('com.iconbit.launcher')
		local t={view='simple'}
		for name in string.gmatch(os.packages(), '([^,]+)') do
			table.insert(t,{title=name,mrl='#stream/q=packages&name=' .. name})
		end
		return t
	elseif args.q == 'music' then
		local t={view='simple'}
		for _, v in ipairs({'One','Two','Three','Four', 'Five'}) do
			local ti = math.random(300)
			table.insert(t,{title=v .. ' ' .. tostring(ti),mrl='#stream/q=music', duration = ti})
		end
		return t
	elseif args.q == 'loop' then
		while true do end
	-- #self/q=db
	elseif args.q == 'db' then
		local db=sqlite3.open('test.db')
		if db then
			db:exec('CREATE TABLE test (name TEXT, value TEXT)')
			db:exec('INSERT INTO test (name,value) VALUES(?,?)','name1','value1')
			db:exec('INSERT INTO test (name,value) VALUES(?,?)','name2','value2')
			db:exec('INSERT INTO test (name,value) VALUES(?,?)','name3','value4')
			local res=db:exec('SELECT * FROM test')
			local t={view='simple'}
			for k,v in ipairs(res) do
				table.insert(t,{title=v.name..' = '..v.value,mrl='#stream/q=message'})
			end
			return t
		end
	elseif args.q == 'accounts' then
		local x = os.accounts('com.google')
		local t={view='select', message = 'Выберите аккаунт'}
		for _, v in ipairs(x) do
			table.insert(t,{title=v,mrl='#stream/q=message'})
		end
		return t
	elseif args.q == 'account' then
		if args.token then
			return {view='msgbox',message='Your token: ' .. args.token}
		end
		return {
			view = 'token',
			scope = 'https://www.googleapis.com/auth/youtube',
			type = 'com.google'
		}
	elseif args.q == 'account1' then
		if args.token then
			return {view='msgbox',message='Your token: ' .. args.token}
		end
		return {
			view = 'token',
			scope = 'https://www.googleapis.com/auth/youtube',
			username = 'aleksmurfik@gmail.com',
			type = 'com.google'
		}
	end
end

--print(L'label')
