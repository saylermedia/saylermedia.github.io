-- files plugin

function onLoad()
	print('Hello from files!')
	return 1
end

function onUnLoad()
	print('Buy from files!')
end

-- path=C:/
function onCreate(args)	
	if not args.q then
		local t={view='list',type='folder'}
		local path=args.path or '/'
		for k,v in ipairs( util.ls (path) ) do
			--print ( v['type'], ' - ', v['url'] )
			if v['type'] == 'folder' then
				table.insert(t,{title=v['title'],mrl='#folder/path='..urlencode(v['url'])})
				--print ( 'add #folder/path='..urlencode(v['url']) )
			else
				local size = math.random(10073741824)
				table.insert(t,{title=v['title'],mrl='#'..v['type']..'/q=show&path='..urlencode(v['url']), size = size})
			end
		end
		return t
	elseif args.q == 'show' then
		return {view='msgbox',message=util.download(args.path)}
	else
		return {view='select',message='Вы выбрали файл: '..args.path,{title='Показать',mrl='#stream/q=show&path='..args.path}}
	end
end
