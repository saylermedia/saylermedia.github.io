
print('lib2 loading')
require('lib1')
