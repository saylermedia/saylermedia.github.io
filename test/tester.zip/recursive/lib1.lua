
print('lib2 loading')
require('lib2')
