-- Recurvive testing

require('lib1')
require('lib2')

function onLoad()
	print('Hello from Recurvive!')
	return 1
end

function onUnLoad()
	print('Buy from Recurvive!')
end

function onCreate(args)
	return {view = 'msgbox', message = 'Hello Recurvive!'}
end
