-- FFI plugin

function onLoad()
	print('Hello from FFI!')
end

function onUnLoad()
	print('Buy from FFI!')
end

local libvlc = ffi.load('libvlc')
ffi.cdef [[
	const char * libvlc_get_version(void);
	typedef struct libvlc_instance_t libvlc_instance_t;
	libvlc_instance_t *libvlc_new( int argc , const char *const *argv );
	void libvlc_release( libvlc_instance_t *p_instance );
	const char * libvlc_get_compiler(void);
	
	typedef struct libvlc_media_t libvlc_media_t;
	libvlc_media_t *libvlc_media_new_location(
                                   libvlc_instance_t *p_instance,
                                   const char * psz_mrl );
	libvlc_media_t *libvlc_media_new_path(
                                   libvlc_instance_t *p_instance,
                                   const char *path );
	void libvlc_media_release( libvlc_media_t *p_md );
	
	typedef int64_t libvlc_time_t;
	libvlc_time_t libvlc_media_get_duration( libvlc_media_t *p_md );
	void libvlc_media_parse( libvlc_media_t *p_md );
]]

local path
if ffi.abi('win') then
	path = 'D:\\test\\vid_bigbuckbunny.mp4'
else
	path = '/sdcard/buck.mp4'
end

local vlc = ffi.gc(libvlc.libvlc_new(0, nil), libvlc.libvlc_release)

function onCreate(args)
	return {
		view = 'simple',
		{title = 'Version: ' .. ffi.string(libvlc.libvlc_get_version()), meta = url_for{}},
		{title = 'Compiler: ' .. ffi.string(libvlc.libvlc_get_compiler()), meta = url_for{}}
	}
end

function onMeta(args)
	local media = ffi.gc(libvlc.libvlc_media_new_path(vlc, path), libvlc.libvlc_media_release)
	libvlc.libvlc_media_parse(media)
	return {duration = libvlc.libvlc_media_get_duration(media) / 1000}
end
