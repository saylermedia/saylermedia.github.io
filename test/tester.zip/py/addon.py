#from __future__ import unicode_literals

import sqlite3
import random
import time
from threading import Thread

from imc import *

#import requests
import sys
print(sys.path)
#import tempfile
#print(extract(tempfile.tempdir, ''))

class MyThread(Thread):

	def __init__(self, name):
		Thread.__init__(self)
		self.name = name

	def run(self):
		#amount = random.randint(1, 3)
		#time.sleep(amount)
		msg = "%s is running" % self.name
		print(msg)
		#print(get_str('view'))
		#print('Mediacenter {} (build {}) on {}'.format(__imcversion__, __imcbuild__, __imcdevice__))
		print(__imclanguage__, __imccountry__)
		print(get_tag('label') + ' ' + get_tag('version'))
		
		
print('Hello from {}!'.format(__imcident__))

def unload():
	print('Buy from {}!'.format(__imcident__))
	
def main(args):
	t = {'view' : 'simple'}

	t['items'] = []
	t['items'].append({'title' : '@string/message', 'url' : url_for('message')})
	t['items'].append({'title' : '@string/error', 'url' : url_for('error')})
	t['items'].append({'title' : '@string/keyword', 'url' : url_for('keyword')})
	t['items'].append({'title' : '@string/select', 'url' : url_for('select')})
	t['items'].append({'title' : '@string/login', 'url' : url_for('login')})
	t['items'].append({'title' : '@string/setup', 'url' : url_for('setup')})
	t['items'].append({'title' : '@string/sqlite', 'url' : url_for('sqlite')})
	t['items'].append({'title' : '@string/sqlite3', 'url' : url_for('sqlite3')})
	
	m = []
	m.append({'title' : 'Genres', 'url' : url_for('genres')})
	m.append({'title' : 'Search', 'url' : url_for('search')})
	t['items'].append({'title' : '@string/label', 'url' : url_for({'genre' : 'anime'}), 'menu' : m, 'size' : 121212, 'free' : 232312320, 'start' : 434234, 'arch' : '?utc=${utc}&lutc=${utc}', 'ago' : 4})

	return t

def message(args):
	for i in range(5):
		MyThread('thread %s' % i).start()
	return {'view' : 'message', 'message' : '@string/description'}

def error(args):
	return {'view' : 'error', 'message' : '@string/description'}

def keyword(args):
	keyword = ''
	if 'keyword' in args:
		keyword = args['keyword']
	return {'view' : 'keyword', 'message' : '@string/description', 'keyword' : keyword}

def select(args):
	return {'view' : 'select', 'message' : '@string/description', 'items' : []}

def login(args):
	return {'view' : 'login', 'message' : '@string/description'}

def setup(args):
	return {'view' : 'setup'}

def sqlite(args):
	return {'view' : 'message', 'message' : str(sqlite3)}

def sqlite3(args):
	con = sqlite3.connect(":memory:")
	cur = con.cursor()
	cur.execute("create table lang (name, first_appeared)")

	# This is the qmark style:
	cur.execute("insert into lang values (?, ?)", ("C", 1972))

	# The qmark style used with executemany():
	lang_list = [
	("Fortran", 1957),
	("Python", 1991),
	("Go", 2009),
	]
	cur.executemany("insert into lang values (?, ?)", lang_list)

	# And this is the named style:
	cur.execute("select * from lang where first_appeared=:year", {"year": 1972})
	message = str(cur.fetchall())

	con.close()
	return {'view' : 'message', 'message' : message}

def event(args):
	print('event: %s' % args['type'])


