-- trace plugin

local urls =
{
	{
		title = 'Видео #1 (обычный просмотр)',
		url = '/sdcard/buck.mp4',
		type = 'video',
		__type__ = 'stream'
	},
	{
		title = 'Видео #2 (управляемое)',
		url = '/sdcard/buck.mp4',
		view = 'playback',
		__type__ = 'stream'
	},
	{
		title = 'Видео #3 (управляемое: прямая ссылка)',
		url = '/sdcard/buck.mp4',
		view = 'playback',
		direct = true,
		__type__ = 'stream'
	},
	{
		title = 'Видео #4 (управляемое: прямая ссылка)',
		url = '/sdcard/buck.mp4',
		view = 'playback',
		direct = true,
		meta = url_for{id = 4},
		__type__ = 'stream'
	},
	{
		title = 'Видео #5 (поток)',
		url = '/sdcard/buck.mp4',
		type = 'stream',
		__type__ = 'stream'
	}
}

function onLoad()
	print('Hello from trace!')
end

function onUnLoad()
	print('Buy from trace!')
end

function onCreate(args)	
	if args['url'] then
		return args
	else
		local t = {view = 'grid'}
		for _, v in ipairs(urls) do
			table.insert(t,{title = v['title'], url = url_for(v)})
		end
		return t
	end
end

function onEvent(e)
	local txt = 'event:'
	for k, v in pairs(e) do
		txt = txt .. ' ' .. tostring(k) .. '=' .. tostring(v)
	end
	print(txt)
end
