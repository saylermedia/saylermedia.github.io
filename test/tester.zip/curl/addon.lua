-- cURL plugin
require('support')

function onLoad()
	print('Hello from cURL!')
	return 1
end

function onUnLoad()
	print('Buy from cURL!')
end

function onCreate(args)
	local data = ''

	local c = cURL.easy_init()
	c:setopt_url("http://172.17.2.145/")
	c:perform{
		writefunction = function (str)
			data = data .. str
		end
	}
	
	local v = cURL.version_info()
	data = data .. '\n' .. json.encode(v)
	
	return {view = 'message', message = data}
end
